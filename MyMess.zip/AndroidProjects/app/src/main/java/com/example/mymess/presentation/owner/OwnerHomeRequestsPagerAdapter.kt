package com.example.mymess.presentation.owner

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class OwnerHomeRequestsPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return if (position == 0) {
            OwnerHomeOrderRequestsFragment()
        } else {
            OwnerHomeJoinRequestsFragment()
        }
    }
}

