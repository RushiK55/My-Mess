package com.example.mymess.presentation.user

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mymess.core.Resource
import com.example.mymess.data.models.Order
import com.example.mymess.data.models.source
import com.example.mymess.databinding.FragmentUserOrdersBinding
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@AndroidEntryPoint
class UserOrdersFragment : Fragment() {

    private var _binding: FragmentUserOrdersBinding? = null
    private val binding get() = _binding!!

    private val viewModel: UserHomeViewModel by viewModels()
    private val adapter = OrderHistoryAdapter { order -> showOrderDetails(order) }
    private var allOrders: List<Order> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentUserOrdersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvOrders.layoutManager = LinearLayoutManager(requireContext())
        binding.rvOrders.adapter = adapter
        binding.btnRefreshOrders.setOnClickListener { viewModel.loadOrderHistory() }

        val dateFilters = listOf("all", "day", "week", "month")
        binding.actDateFilter.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, dateFilters))
        binding.actDateFilter.setText("all", false)
        binding.actDateFilter.setOnClickListener { binding.actDateFilter.showDropDown() }
        binding.actDateFilter.setOnItemClickListener { _, _, _, _ -> applyFilters() }

        val statusFilters = listOf("all", "pending", "accepted", "preparing", "ready", "delivered", "cancelled")
        binding.actStatusFilter.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, statusFilters))
        binding.actStatusFilter.setText("all", false)
        binding.actStatusFilter.setOnClickListener { binding.actStatusFilter.showDropDown() }
        binding.actStatusFilter.setOnItemClickListener { _, _, _, _ -> applyFilters() }

        binding.etSearchOrders.addTextChangedListener { applyFilters() }
        observeState()
        viewModel.loadOrderHistory()
    }

    private fun showOrderDetails(order: Order) {
        val format = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val instructions = order.specialInstructions?.takeIf { it.isNotBlank() } ?: "None"
        AlertDialog.Builder(requireContext())
            .setTitle(order.mealName)
            .setMessage(
                "Quantity: ${order.quantity}\n" +
                    "Order source: ${order.source()}\n" +
                    "Total: Rs ${order.totalPrice}\n" +
                    "Status: ${order.status}\n" +
                    "Payment: ${order.paymentStatus}\n" +
                    "Special instructions: $instructions\n" +
                    "Placed at: ${format.format(Date(order.createdAt))}"
            )
            .setPositiveButton("Close", null)
            .show()
    }

    private fun applyFilters() {
        val query = binding.etSearchOrders.text?.toString().orEmpty().trim().lowercase()
        val dateFilter = binding.actDateFilter.text?.toString().orEmpty().ifBlank { "all" }
        val statusFilter = binding.actStatusFilter.text?.toString().orEmpty().ifBlank { "all" }

        val now = System.currentTimeMillis()
        val filtered = allOrders.filter { order ->
            val searchOk = query.isBlank() || order.mealName.lowercase().contains(query) || order.status.lowercase().contains(query)
            val statusOk = statusFilter == "all" || order.status == statusFilter
            val dateOk = when (dateFilter) {
                "day" -> now - order.createdAt <= 24 * 60 * 60 * 1000L
                "week" -> now - order.createdAt <= 7 * 24 * 60 * 60 * 1000L
                "month" -> now - order.createdAt <= 30L * 24 * 60 * 60 * 1000
                else -> true
            }
            searchOk && statusOk && dateOk
        }
        adapter.submitList(filtered)
        binding.tvInfo.text = if (filtered.isEmpty()) "No matching orders" else "Total orders: ${filtered.size}"
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.historyState.collect { state ->
                    when (state) {
                        is Resource.Error -> {
                            binding.progressBar.visibility = View.GONE
                            binding.tvInfo.text = state.message
                        }

                        Resource.Loading -> {
                            binding.progressBar.visibility = View.VISIBLE
                            binding.tvInfo.text = "Loading orders..."
                        }

                        is Resource.Success -> {
                            binding.progressBar.visibility = View.GONE
                            allOrders = state.data
                            applyFilters()
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
